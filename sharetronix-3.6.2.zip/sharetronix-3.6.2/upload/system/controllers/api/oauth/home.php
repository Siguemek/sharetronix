<?php
	
	$this->redirect($C->SITE_URL.'api');
	
?>