<?php

	$this->redirect('home');