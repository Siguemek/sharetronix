<?php
	
	$cache->garbage_collector();
	
?>