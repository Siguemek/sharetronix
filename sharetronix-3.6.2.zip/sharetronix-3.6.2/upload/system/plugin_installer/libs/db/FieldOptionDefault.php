<?php
class FieldOptionDefault extends FieldOption {
	
	/**
	 * FieldOptionDefault	
	 * 
	 * @access	public
	 * @param 	mixed	 $value
	 */
	public function FieldOptionDefault($value) {
		parent::FieldOption($value);
	}
	
}