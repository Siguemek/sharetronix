<?php

class FieldOptionLimit extends FieldOption {
	
	
	/**
	 * FieldOptionLimit
	 * 
	 * @access	public
	 * @param 	int		 $value
	 */
	public function FieldOptionLimit($value){
		parent::FieldOption((int)$value);
	}
	
}