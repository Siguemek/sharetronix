<?php
	
	$lang	= array
	(
		'dmncnfrm_err_title'	=> 'Domain ownership confirmation',
		'dmncnfrm_err_msgttl'	=> 'Sorry',
		'dmncnfrm_err_msg_deadlink'	=> 'The link brought you to this location is invalid or expired. ',
		'dmncnfrm_err_msg_cannot'	=> 'This domain cannot be added to #COMPANY# network. Please try again later.',
	);
	
?>