<?php
	
	$lang	= array
	(
		'terms_pgtitle'	=> 'Terms of Use - #SITE_TITLE#',
		
		'terms_title'	=> 'Terms of Use - #SITE_TITLE#',
	);
	 
?>