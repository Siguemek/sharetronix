<?php
	
	$lang = array
	(
		'userselector_tab_all'	=> 'All',
		'userselector_tab_sel'	=> 'Selected',
		'userselector_srchinp'	=> 'Search Members',
		 
		'home_login_sample'	=> 'yourname@yourcompany.com',
		
		'fly_login_title'	=> 'Sign In',
		'fly_login_email'	=> 'E-mail:',
		'fly_login_pass'	=> 'Password:',
		'fly_login_btn'	=> 'Sign In',
		'fly_login_rem'	=> 'Remember me',
		'fly_login_forg'	=> 'Forgot your password?',
			
		'outside_register_with_fb_tw' => 'You should fill your email in the field below and confirm it before proceeding to ',
	);
	
?>