<?php
	
	$lang	= array
	(
		'os_home_page_title'	=> '#SITE_TITLE# - Your Micro-Social Network',
		
		'os_welcome_ttl'	=> 'Welcome to #SITE_TITLE# Community',
		'os_welcome_txt'	=> 'With #SITE_TITLE# users can communicate using quick status updates of 160 characters or less. This free flowing dialogue lets you send messages, pictures and video to anyone! It`s also easy to find and connect with other people for private threads and to keep track of their updates. All this and more in a simple interface.',
		'os_welcome_btn'	=> 'Join Now',
		'os_login_ttl'	=> 'Sign in',
		'os_login_unm'	=> 'Username:',
		'os_login_pwd'	=> 'Password',
		'os_login_btn'	=> 'Sign In',
		'os_login_rem'	=> 'Remember me',
		'os_login_reg'	=> 'Create New Account',
		'os_login_frg'	=> 'Forgotten Password',
		'os_login_email_username'	=> 'Email or username',
		'os_login_btn_txt'	=> 'Login',
			
		'os_noposts_ttl'=>'No posts',
		'os_noposts_unreg_mgs' => 'There are no posts visible for not registered users.',
		'os_noposts_match_mgs' => 'There are no posts matching your criteria.',
			
		'os_already_user' => 'Already a user? Sign in',
	);
	
?>