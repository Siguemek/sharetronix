<?php
	
	$lang	= array
	(
		'ftr_contacts'	=> 'Contacts',
		'ftr_legal'		=> 'Legal',
		'ftr_faq'		=> 'FAQ',
		'ftr_api'		=> 'API',
		
		'page_footer_text_invite' => 'Invite',
		'page_footer_text_faq' => 'FAQ',
	);
	
?>