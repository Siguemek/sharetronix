<?php
	
	$lang	= array
	(
		'mainnav_backtohome'	=> '#SITE_TITLE# Homepage',
	);
	
?>