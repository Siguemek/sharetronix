<?php
	
	$lang	= array
	(
		'iprestriction_page_title'	=> 'IP Restriction - #SITE_TITLE#',
		
		'iprestriction_title'		=> 'IP Restriction',
		'iprestriction_msg_title'	=> 'You cannot access the #COMPANY# network from this computer.',
		'iprestriction_msg_text'	=> 'The network administrator has applied IP restrictions to the network and it seems that your IP address is not allowed to access.<br />You can <a href="#COMPANY_URL#signin">sign in</a> from this IP only if you are network administrator.',
	);
	
?>