<?php
	
	$lang	= array
	(
		'prof_changemail_subject'	=> 'Confirm your e-mail in #SITE_TITLE#',
		'prof_changemail_hello'		=> 'Hello,',
		'prof_changemail_message'	=> 'To confirm your new e-mail address in #SITE_TITLE#, please use the following link:',
		'prof_changemail_warning'	=> 'In case you have not requested an e-mail change, please disregard this message.',
		'prof_changemail_signature'	=> "Regards,\n#SITE_TITLE#",
	);
	
?>