<?php
	
	$lang	= array
	(
		'domainconfirm_email_subject'	=> '#DOMAIN# ownership confirmation',
		'domainconfirm_email_hello'	=> 'Hello,',
		'domainconfirm_email_message'	=> 'To confirm the domain #DOMAIN# ownership in #SITE_TITLE#, please use the following link:',
		'domainconfirm_email_warning'	=> 'In case you have not requested this confirmation, please disregard this message.',
		'domainconfirm_email_signature'	=> "Regards,\n#SITE_TITLE#",
	);
	
?>