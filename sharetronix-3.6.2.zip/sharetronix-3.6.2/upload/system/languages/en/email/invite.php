<?php
	
	$lang	= array
	(
		'invite_email_subject'	=> 'Join #COMPANY# private network',
		'invite_email_hello'	=> '#WHOM#,',
		'invite_email_message'	=> '#WHO# invites you to join #COMPANY# private network.',
		'invite_email_regtext'	=> 'To sign up, use the following link:',
		'invite_email_signature'	=> "Regards,\n#SITE_TITLE#",
		
		'os_invite_email_subject'	=> 'Join #SITE_TITLE#',
		'os_invite_email_hello'		=> '#WHOM#,',
		'os_invite_email_message'	=> '#WHO# invites you to join #SITE_TITLE#.',
		'os_invite_email_regtext'	=> 'To sign up, use the following link:',
		'os_invite_email_signature'	=> "Regards,\n#SITE_TITLE#",
	);
	
?>