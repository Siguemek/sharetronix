<?php
	
	$lang	= array
	(
		'signinforg_email_subject'	=> 'Forgotten Password in #SITE_TITLE#',
		'signinforg_email_hello'	=> 'Hello,',
		'signinforg_email_message'	=> 'To restore your password in #SITE_TITLE#, please use the following link:',
		'signinforg_email_warning'	=> 'In case you have not requested a password recovery, please disregard this message.',
		'signinforg_email_signature'	=> "Regards,\n#SITE_TITLE#",
	);
	
?>