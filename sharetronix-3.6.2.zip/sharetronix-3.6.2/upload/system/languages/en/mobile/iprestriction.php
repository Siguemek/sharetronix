<?php
	
	$lang	= array
	(
		'iprestriction_message'	=> 'You cannot access the #COMPANY# network from here. The network administrator has applied IP restrictions to the network and it seems that your IP address is not allowed to access.',
	);
	
?>