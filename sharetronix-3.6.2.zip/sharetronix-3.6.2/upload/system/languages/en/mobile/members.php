<?php
	
	$lang = array
	(
		'members_page_title_following'	=> 'Members I Follow - #SITE_TITLE#',
		'members_page_title_followers'	=> 'My Followers - #SITE_TITLE#',
		'members_page_title_everybody'	=> 'Network Members - #SITE_TITLE#',
		
		'members_top_title'	=> 'Members',
		'members_top_menu_following'	=> 'Members I follow',
		'members_top_menu_followers'	=> 'My followers',
		'members_top_menu_everybody'	=> 'All network members',
		'members_top_menu_submit'	=> 'Go',
		
		'members_nores_following'	=> 'You don\'t follow anybody yet.',
		'members_nores_followers'	=> 'You don\'t have followers yet.',
		'members_nores_everybody'	=> 'No members found.',
		
		'iphone_members_menu_following'	=> 'I Follow',
		'iphone_members_menu_followers'	=> 'My Followers',
		'iphone_members_menu_everybody'	=> 'Everybody',
		'iphone_members_menu_admins'		=> 'Admins',
		'iphone_members_no_following'	=> 'You don\'t follow anybody yet.',
		'iphone_members_no_followers'	=> 'Nobody is following you yet.',
		'iphone_members_no_admins'		=> 'There are no network administrators yet.',
	);
	
?>