<?php
	
	$lang	= array
	(
		'mobidisabled_message'	=> 'Mobile interface is currently disabled for this network.'
	);
	
?>