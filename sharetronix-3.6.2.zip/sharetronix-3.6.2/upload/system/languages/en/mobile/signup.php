<?php
	
	$lang	= array
	(
		'm_signup_using_email' => 'Sign up with your email address.',
		'm_signup_steps' => 'Step ',
		'm_signup_page_title' => 'Email: ',
		'm_site_title'=>'Sign Up - #SITE_TITLE#',
		'm_signup_continue'=>'Continue',
	);
	
?>