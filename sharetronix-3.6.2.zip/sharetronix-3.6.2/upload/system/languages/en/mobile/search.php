<?php
	
	$lang	= array
	(
		'search_title_users'	=> 'Find Users - #SITE_TITLE#',
		'search_title_posts'	=> 'Find Posts - #SITE_TITLE#',
		'search_title_groups'	=> 'Find Groups - #SITE_TITLE#',
		
		'search_form_title'	=> 'Search for:',
		'search_form_in'		=> 'in:',
		'search_form_submit'	=> 'Search',
		
		'search_menu_users'	=> 'Members',
		'search_menu_posts'	=> 'Posts',
		'search_menu_groups'	=> 'Groups',
		
		'search_nores'	=> 'No results matching your search criteria.',
		
		'iphone_srch_posts1'	=> 'Search Posts',
		'iphone_srch_users1'	=> 'Search Users',
		'iphone_srch_groups1'	=> 'Search Groups',
		'iphone_srch_posts2'	=> 'Posts',
		'iphone_srch_users2'	=> 'Users',
		'iphone_srch_groups2'	=> 'Groups',
		'iphone_saved_searches'	=> 'Saved Searches',
	);
	
?>