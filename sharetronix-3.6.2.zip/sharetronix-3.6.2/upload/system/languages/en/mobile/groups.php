<?php
	
	$lang = array
	(
		'groups_page_title_my'	=> 'My Groups - #SITE_TITLE#',
		'groups_page_title_all'	=> 'All Groups - #SITE_TITLE#',
		
		'groups_top_title'	=> 'Groups',
		'groups_top_menu_my'	=> 'My groups',
		'groups_top_menu_all'	=> 'All groups',
		'groups_top_menu_submit'	=> 'Go',
		
		'groups_nores_my'		=> 'You are not a member of any group yet.',
		'groups_nores_all'	=> 'There are no groups yet.',
		
		'iphone_groups_menu_my'		=> 'My Groups',
		'iphone_groups_menu_all'	=> 'All Groups',
		'iphone_groups_no_my'		=> 'You are not a member of any group yet.',
		'iphone_groups_no_all'		=> 'There are no groups yet.',
	);
	
?>