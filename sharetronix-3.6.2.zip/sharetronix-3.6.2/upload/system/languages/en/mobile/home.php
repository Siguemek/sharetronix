<?php
	
	$lang	= array
	(
		'home_page_title'	=> 'Sign In - #SITE_TITLE#',
		
		'home_form_title'	=> 'Welcome to #SITE_TITLE# mobile version',
		'home_form_email'	=> 'E-mail:',
		'home_form_pass'	=> 'Password:',
		'home_form_rmbme'	=> 'Remember&nbsp;me',
		'home_form_btn'	=> 'sign in',
		'home_form_errmsg'	=> 'Wrong e-mail or password.',
		'home_form_btn_signup'	=> 'sign up',
		
		'homechnetw_form_title'		=> 'Choose a Network',
		'homechnetw_form_text'		=> 'Looks like you are a member of more then one network on #SITE_TITLE#. You need to choose which network you want to access:',
		'homechnetw_form_submit'	=> 'Continue',
		'homechnetw_privnet'	=> 'company network',
		'homechnetw_pubnet'	=> 'public network',
	);
	
?>