<?php
	
	$lang	= array
	(
		'header_nav_home'		=> 'Home',
		'header_nav_newpost'	=> 'Post',
		'header_nav_profile'	=> 'Profile',
		'header_nav_search'	=> 'Search',
		
		'iphone_nav_dashboard'	=> 'Dashboard',
		'iphone_nav_newpost'	=> 'New Post',
		'iphone_nav_members'	=> 'Members',
		'iphone_nav_groups'	=> 'Groups',
		'iphone_nav_search'	=> 'Search',
		'iphone_nav_signout'	=> 'Sign Out',
	);
	
?>