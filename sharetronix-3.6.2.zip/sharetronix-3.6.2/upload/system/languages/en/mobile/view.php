<?php
	
	$lang	= array
	(
		'vpost_cmnts_all'		=> 'Comments',
		'vpost_cmnts_allpg'	=> 'page #NUM# of #NUM2#',
		'vpost_cmnts_latest'	=> 'Last #NUM# comments',
		'vpost_cmnts_viewall'	=> 'view all',
		'vpost_cmnts_add'		=> 'Add comment',
		'vpost_cmnts_add_sbm'	=> 'Comment',
		
		'vpost_video'	=> 'Video:',
		
		'vpost_ftr_mention'	=> 'Post @#USERNAME#',
		'vpost_ftr_profile'	=> 'Back to #USERNAME#\'s profile',
		'vpost_ftr_group'		=> 'Back to #GROUP#',
		
		'iphone_vpost_cmnts_1'		=> '1 Comment',
		'iphone_vpost_cmnts_mr'		=> '#NUM# Comments',
		'iphone_vpost_cmnts_1_x'	=> '1 Private Comment',
		'iphone_vpost_cmnts_mr_x'	=> '#NUM# Private Comments',
		'iphone_vpost_addcommentlink'	=> 'Add',
		'iphone_vpost_addcommentttl'	=> 'Add a comment',
		'iphone_vpost_addcommentttlx'	=> 'Add a private comment',
		'iphone_vpost_addcommentbtn'	=> 'Add Comment',
		'iphone_vpost_delcomment'	=> 'Delete',
		'iphone_vpost_delcomment_c'	=> 'Delete this comment?',
		
		'iphone_vpost_atchpost'	=> 'Attached Post:',
		'iphone_atpost_cmnts_1'		=> '1 Public Comment',
		'iphone_atpost_cmnts_mr'	=> '#NUM# Public Comments',
		'iphone_atpost_addcommentlnk'	=> 'Add',
		'iphone_atpost_addcommentttl'	=> 'Add a public comment',
		'iphone_atpost_addcommentbtn'	=> 'Add Public Comment',
	);
	
?>