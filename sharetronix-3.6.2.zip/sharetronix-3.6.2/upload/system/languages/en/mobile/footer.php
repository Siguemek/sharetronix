<?php
	
	$lang	= array
	(
		'footer_nav_members'	=> 'Browse Members',
		'footer_nav_groups'	=> 'Browse Groups',
		'footer_nav_signout'	=> 'Sign Out',
		
		'footer_mobi_touch'	=> 'Touch version',
		'footer_mobi_simple'	=> 'Simple version',
	)
	
?>