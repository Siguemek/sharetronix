<?php
	
	$lang	= array 
	(
	);
	
?>