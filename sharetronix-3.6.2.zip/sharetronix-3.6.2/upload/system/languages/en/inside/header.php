<?php
	
	$lang	= array
	(
		'hdr_nav_home'		=> 'Home',
		'hdr_nav_users'		=> 'Members',
		'hdr_nav_groups'		=> 'Groups',
		'hdr_nav_admin'		=> 'Administration',
		'hdr_nav_admin2'		=> 'Admin',
		'hdr_nav_profile'		=> 'Profile',
		'hdr_nav_settings'	=> 'Settings',
		'hdr_nav_signin'		=> 'Sign in',
		'hdr_nav_signup'		=> 'Sign up',
		'hdr_nav_signas'		=> 'Sign in as a different user',
		'hdr_nav_signout'		=> 'Sign out',
		'hdr_nav_search'		=> 'Search',
		'hdr_nav_invite'		=> 'Invite Colleagues',
		'os_hdr_nav_invite'	=> 'Invite Friends',
		
		'hdr_navv_members_all'		=> 'All Members',
		'hdr_navv_members_ifollow'	=> 'I Follow',
		'hdr_navv_members_followme'	=> 'My Followers',
		'hdr_navv_members_admins'	=> 'Admins',
		'hdr_navv_groups_all'		=> 'All Groups',
		'hdr_navv_groups_my'		=> 'My Groups',
		'hdr_navv_groups_new'		=> 'Create Group',
		
		'hdr_search_posts'	=> 'Posts',
		'hdr_search_users'	=> 'Members',
		'hdr_search_groups'	=> 'Groups',
		'hdr_search_submit'	=> 'Search',
		
		'sharetronix_install_ok_ttl'	=> 'Done',
		'sharetronix_install_ok_txt'	=> 'Sharetronix #VER# was successfully installed.',
		
		'hdr_search_competitions'	=> 'Leaders',
		'hdr_search_tags'	=> 'Tags',
		
		'hdr_pf_at_image'		=> 'Image:',
		'hdr_pf_at_link'		=> 'Link:',
		'hdr_pf_at_file'		=> 'File:',
		'hdr_pf_at_videoembed'		=> 'Video:',
	);
	
?>