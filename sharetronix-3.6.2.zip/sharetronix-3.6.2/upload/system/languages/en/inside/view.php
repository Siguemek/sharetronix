<?php
	
	$lang = array
	(
		'viewpost_hdr_prevpost'	=> 'Previous Post',
		'viewpost_hdr_nextpost'	=> 'Next Post',
		'viewpost_hdr_profile'	=> '#USERNAME#\'s profile',
		
		'vpgroup_subtitle_type_public'	=> 'Public group',
		'vpgroup_subtitle_type_private'	=> 'Private group',
		'vpgroup_subtitle_nm_posts'	=> '#NUM# posts',
		'vpgroup_subtitle_nm_posts1'	=> '1 post',
		'vpgroup_subtitle_nm_members'	=> '#NUM# members',
		'vpgroup_subtitle_nm_members1'	=> '1 member',
		
		'viewpost_attached_image'	=> 'Attached Image:',
		'viewpost_attached_video'	=> 'Attached Video:',
		
		'viewpost_date_format'		=> '%b %d %Y, %H:%M',
		
		'viewpost_comment_submit'	=> 'Add Comment',
		
		'viewpost_attached_images'	=> 'Attached Images:',
		'viewpost_attached_videos'	=> 'Attached Videos:',
		'viewpost_attached_links'	=> 'Attached Links:',
		'viewpost_attached_files'	=> 'Attached Files:',
		
		'viewpost_page_title' => 'View Post',
	);
	
?>