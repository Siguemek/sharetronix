<?php
	
	$lang	= array
	(
		'groups_page_title_all'	=> 'All Groups - #SITE_TITLE#',
		'groups_page_title_my'	=> 'My Groups - #SITE_TITLE#',
		
		'groups_page_ttl2'	=> 'Groups',
		'groups_page_tab_all'	=> 'All Groups',
		'groups_page_tab_my'	=> 'My Groups',
		'groups_page_tab_add'	=> 'Create New Group',
		'groups_page_tab_special'	=> 'Special Groups',
		
		'groups_msgbox_deleted_ttl'	=> 'Done',
		'groups_msgbox_deleted_txt'	=> 'Group was deleted.',
		
		'nogroups_box_ttl_all'	=> 'No groups',
		'nogroups_box_txt_all'	=> 'You can create the first group in the network.',
		'nogroups_box_ttl_my'	=> 'No groups',
		'nogroups_box_txt_my'	=> 'You haven\'t joined any group yet.',
		'nogroups_box_ttl_special'	=> 'No groups',
		'nogroups_box_txt_special'	=> 'There are no special groups yet.',
		'nogroups_box_ttl_default'	=> 'No groups',
		'nogroups_box_txt_default'	=> 'No groups found.',
		
		'groups_page_title_special' 	=> 'Special Groups',
	);
	
?>