<?php
	
	$lang	= array
	(
		'newgroup_title'	=> 'New Group - #SITE_TITLE#',
		'newgroup_title2'	=> 'Create New Group',
		
		'newgroup_f_btn'	=> 'Create Group',
		'newgroup_f_err'	=> 'Error',
			
		'newcat_page_title'	=> 'Add new group category',
		'newcat_submit_btn' => 'Submit',
		'newcat_form_title' => 'Add new group category',
		'newcat_create_new' => 'Create a new group category',
		'newcat_invalid_name' => 'Invalid category name',
		'newcat_name_already_exists' => 'Category name already exists',
		'newcat_info_field' => 'Group category title could be 3 to 30 charactes long and could contain only a-z, _, space, - and 0-9 characters.',
		'newcat_success_text' => 'Category created successfully',
		'newcat_success_title' => 'Success',
		'newcat_invalid' => 'Invalid category',
	);
	
?>