<?php
	
	$lang	= array
	(
		'grpinv_pagetitle'	=> 'Invite colleagues to #GROUP# - #SITE_TITLE#',
		'grpinv_title'		=> 'Invite colleagues to join #GROUP#',
		
		'os_grpinv_pagetitle'	=> 'Invite people to #GROUP# - #SITE_TITLE#',
		'os_grpinv_title'		=> 'Invite people to join #GROUP#',
		
		'grpinv_nobody_ttl'	=> 'Nobody to invite',
		'grpinv_nobody_txt'	=> 'All network members have already joined #GROUP#.',
		
		'grpinv_submit'		=> 'Send Invitations',
		'grpinv_submit_or'	=> 'or',
		'grpinv_submit_or_back'	=> 'go back to group',
		'grpinv_submit_err'	=> 'Choose at lease one member.',
			
		'group_invite_people'		=> 'Invite people',
		'group_invite_people_sbm_btn'		=> 'Invite',
	);
	
?>