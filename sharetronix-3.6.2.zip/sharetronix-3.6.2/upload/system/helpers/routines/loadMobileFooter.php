<?php 
	function loadMobileFooter( $tpl, $params )
	{ 

	}
?>