<?php 
	function loadOutsideFooter( $tpl, $params )
	{ 
		$tpl->layout->setVar('stx_footer_link_abc', 'Powered by <a href="http://sharetronix.com" target="_blank">Sharetronix</a>');
	}
?>