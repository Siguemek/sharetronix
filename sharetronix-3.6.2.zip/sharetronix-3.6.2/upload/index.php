<?php
	/**
	 * SHARETRONIX OPENSOURCE
	 * 
	 * @author	Vassil Maldjov
	 * @author	Ivaylo Enev
	 * @author	Nick Dimitrov
	 * @author	Veselin Hadjiev
	 * @author	Georgi Yanev
	 * @author	Nikola Pavlov
	 * @author	Petar Iliev
	 * @author	Sofiya Dimitrov
	 * @contact	support@sharetronix.com
	 * @license	LICENSE.TXT
	 */

	if(defined('PROJPATH') == false)
	{
		define('PROJPATH', dirname(__FILE__) . DIRECTORY_SEPARATOR);
	}	

	require_once('./system/LOADER.php');
	
?>