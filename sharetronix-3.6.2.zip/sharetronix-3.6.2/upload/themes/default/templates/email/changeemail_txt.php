<?= $this->lang('prof_changemail_hello') ?>

<?= $this->lang('prof_changemail_message', array('#SITE_TITLE#'=>$C->SITE_TITLE, '#SITE_URL#'=>$C->SITE_URL)) ?>
<?= $D->confirmation_link ?>

<?= $this->lang('prof_changemail_warning', array('#SITE_TITLE#'=>$C->SITE_TITLE, '#SITE_URL#'=>$C->SITE_URL)) ?>

<?= $this->lang('prof_changemail_signature', array('#SITE_TITLE#'=>$C->SITE_TITLE, '#SITE_URL#'=>$C->SITE_URL)) ?>