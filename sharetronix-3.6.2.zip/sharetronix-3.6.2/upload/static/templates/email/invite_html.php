<?= nl2br($this->lang('os_invite_email_hello', $D->lang_keys)) ?><br />
<br />
<?= nl2br($this->lang('os_invite_email_message', $D->lang_keys)) ?><br />
<br />
<?= nl2br($this->lang('os_invite_email_regtext', $D->lang_keys)) ?><br />
<a href="<?= $D->registration_link ?>" target="_blank"><?= $D->registration_link ?></a><br />
<br />
<?= nl2br($this->lang('os_invite_email_signature', $D->lang_keys)) ?><br />
<br />