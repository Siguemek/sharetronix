<?= $this->lang('os_invite_email_hello', $D->lang_keys) ?>

<?= $this->lang('os_invite_email_message', $D->lang_keys) ?>

<?= $this->lang('os_invite_email_regtext', $D->lang_keys) ?>
<?= $D->registration_link ?>

<?= $this->lang('os_invite_email_signature', $D->lang_keys) ?>