<?= $this->lang('signinforg_email_hello') ?>

<?= $this->lang('signinforg_email_message', array('#SITE_TITLE#'=>$C->SITE_TITLE, '#SITE_URL#'=>$C->SITE_URL)) ?>
<?= $D->recover_link ?>

<?= $this->lang('signinforg_email_warning', array('#SITE_TITLE#'=>$C->SITE_TITLE, '#SITE_URL#'=>$C->SITE_URL)) ?>

<?= $this->lang('signinforg_email_signature', array('#SITE_TITLE#'=>$C->SITE_TITLE, '#SITE_URL#'=>$C->OUTSIDE_SITE_URL)) ?>