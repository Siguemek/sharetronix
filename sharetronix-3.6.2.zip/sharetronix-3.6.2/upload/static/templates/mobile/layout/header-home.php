<!DOCTYPE html>
<html lang="{%html_lang_abbrv%}">
	<head>
		<title>{%page_title%}</title>
		{%header_data%}
		<meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
	</head>
	<body>
	
		<div id="logo">
			{%logo_data%}
			<div class="clear"></div>
		</div>