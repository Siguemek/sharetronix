<section id="content-container" data-role="content">
	{%main_content_placeholder%}
	{%main_content%}
	{%main_content_bottom%}
</section>