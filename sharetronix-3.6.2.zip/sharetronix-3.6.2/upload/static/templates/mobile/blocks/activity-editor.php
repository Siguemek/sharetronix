<div class="status-editor">
	<div class="user-status-field-container" data-type="{%postform_type%}">
		<div class="data-content-placeholder">
			<div class="status-editor-container">
				{%editor_textarea%}
				{%editor_character_limit%}
			</div>
			
			<div class="status-editor-options">
				<div class="attachments uploads" id="0f768e1c400608">
					<div class="images"></div>
					<div class="links"></div>
					<div class="files"></div>
					{%editor_attachment_uploads%}
				</div>
				<div class="status-editor-buttons">
					{%editor_attachment_options%}
					{%editor_btn_placeholder%}
					
				</div>
				<div class="clear"></div>
			
			</div>
			
		</div>
	</div>
	
	<div class="clear"></div>
</div>