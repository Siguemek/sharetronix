<textarea class="htmlarea" name="message" tabindex="1" data-value="<?= $this->page->lang('activity_text_box_shate_txt') ?> {%in_group%}"></textarea>

<div class="htmlarea-ac">
	<div class="htmlarea-ac-container"></div>
</div>