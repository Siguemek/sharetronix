<li>
	<div class="comment {%activity_comment_new%}">
		{%activity_comment_user_avatar%}
		<div class="comment-container">
			<div class="comment-header">
				{%activity_comment_user_username%}
				<span class="permlink">{%activity_comment_date%}</span>
			</div>
			
			<div class="comment-content">
				{%activity_comment_text%}
			</div>
		</div>
		<div class="clear"></div>
	</div>
</li>