<div class="container">
	<!-- <a target="_blank" href="{%activity_attachments_link%}" class="thumb"><img src="<?= $C->STATIC_URL.'images/link_thumb.png'; ?>"></a> -->
	<div class="content text-info">
		<a target="_blank" href="{%activity_attachments_link%}" class="link-title">{%activity_attachments_link_title%}</a>
		<span>
			{%activity_attachments_link_description%}
		
		</span>
	</div>
	<div class="clear"></div>
</div>	