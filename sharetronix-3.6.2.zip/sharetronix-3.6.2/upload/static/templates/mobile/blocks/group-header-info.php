<div class="subheader-container">
	<h1 class="group-type {%group_header_icon%}">{%group_header_username%}</h1>
	<div class="statistics">{%group_header_activity%}</div>
	<div class="options-container">{%group_header_settings_button%}</div>
</div>