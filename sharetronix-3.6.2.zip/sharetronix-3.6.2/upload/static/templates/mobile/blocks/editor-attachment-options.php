<div class="attachments-options">

	<a href="#" class="attachment-button ac-btn"><span><?= $this->page->lang('activity_option_user') ?></span></a>
	<a href="#" class="file attachment-button"><span><?= $this->page->lang('activity_option_photo') ?></span></a>
	<a href="#" class="link attachment-button"><span><?= $this->page->lang('activity_option_link') ?></span></a>
	<div class="attachment-link-field-container" style="display: none;">
		<input type="text" class="attachment-link-field" value="">
		<a href="#" class="attachment-button add-link"><?= $this->page->lang('activity_option_attach') ?></a>
	</div>

	<span class="uploading"><?= $this->page->lang('activity_option_upload_txt') ?></span>
	<div class="clear"></div>

</div>