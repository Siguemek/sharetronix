<div class="activity-feed-list">
	{%activity-container-list%}
</div>
{%activity_container_show_more%}