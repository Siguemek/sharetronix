<div class="subheader-container">
	<h1>{%user_header_username%}</h1>
	<span>{%user_header_position%}</span>
	<div class="statistics">{%user_header_activity%}</div>
	<div class="options-container">{%user_header_follow_button%}</div>
</div>