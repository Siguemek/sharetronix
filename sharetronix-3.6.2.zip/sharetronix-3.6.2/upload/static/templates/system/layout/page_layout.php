	<div id="left-area" class="sidebar">
		{%left_content_placeholder%}
		{%left_content%}
		{%left_content_bottom%}
	</div>
	<div id="content-container">
		
		<div id="subheader">
			{%main_content_top_placeholder%}
			{%subheader_placeholder%}
		</div>
		<div id="center-container">
			{%main_content_placeholder%}
			{%main_content%}
			{%main_content_bottom%}
		</div>
		<div id="right-area" class="sidebar">
			{%right_content_placeholder%}
			{%right_content%}
			{%right_content_bottom%}
		</div>
	</div>
	<div class="clear"></div>