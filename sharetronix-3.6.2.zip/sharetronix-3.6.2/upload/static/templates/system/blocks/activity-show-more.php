<div class="show-more-container">
	<div class="loading-container"><div class="loading-indicatior"></div></div>
	<a href="" data-action="getMore" data-namespace="activities" data-role="services" data-value="{%activities_pager_value%}" class="show-more"><span><?= $this->page->lang('activity_show_more_btn_txt') ?></span></a>
</div>