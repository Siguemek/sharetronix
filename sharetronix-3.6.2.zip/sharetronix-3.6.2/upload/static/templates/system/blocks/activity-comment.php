<li>
	<div class="comment {%activity_comment_new%}">
		{%activity_comment_user_avatar%}
		<div class="comment-container">
		
			<div class="comment-options">{%activity_comment_options%}</div>
			<div class="comment-content"><span class="comment-author">{%activity_comment_user_username%}</span> {%activity_comment_text%}</div>
			<div class="attachments"></div>
			<div class="meta-info">
				<span class="permlink">{%activity_comment_date%}</span>
				<!--  <a class="reply" title="Reply">Reply</a> -->
				{%activity_comment_footer%}
			</div>
		</div>
		<div class="clear"></div>
	</div>
</li>