{%show_all_activity_comments%}
<ol class="comments-thread">
	<li>{%activity_comments%}</li>
</ol>