<div class="attachments">
	<div class="images">
		<div class="list-link-container">
			{%activity_attachment_images%}
			<!-- <a target="_blank" href="" class="lightbox-image image-thumb cboxElement"><img alt="filename" src="{%activity_attachment_image_src%}"></a> -->
			<!-- //this is placeholder for video player <div class="video-placeholder"></div>  -->
		</div>
	
	</div>
	<div class="links">
		{%activity_attachments_links%}		
	</div>
	<div class="files">
		{%activity_attachments_files%}
	</div>
</div>