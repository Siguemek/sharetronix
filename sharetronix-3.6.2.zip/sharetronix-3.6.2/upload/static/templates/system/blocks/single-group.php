<div class="group-section {%single_group_type%} {%group_icon%}">

	<div class="avatar">{%single_group_avatar%}</div>

	<div class="details">
		<div class="title">{%single_group_name%}</div>
		<div class="statistics">{%single_group_activity%}</div>
		<div class="description">{%single_group_description%}</div>
	</div>
	
	<div class="options-container">{%single_group_join_leave%}</div>
	
	<div class="clear"></div>
</div>