<div class="user-status-field htmlarea">
	<div class="textarea-wrap">
		<textarea name="message" tabindex="1" data-placeholder="<?= $this->page->lang('activity_text_box_shate_txt') ?> {%in_group%}..."><?= $this->page->lang('activity_text_box_shate_txt') ?> {%in_group%}...</textarea>
		<div class="textarea-highlighter"><span></span></div>
	</div>
</div>

<div class="htmlarea-ac">
	<div class="htmlarea-ac-container"></div>
	
</div>
