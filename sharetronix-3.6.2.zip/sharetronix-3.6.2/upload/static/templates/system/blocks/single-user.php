<div class="people-section {%single_user_float%}"> <!-- left-container, right-container -->

	<div class="avatar">{%single_user_avatar%}</div>

	<div class="details">
	
		<div class="title">{%single_user_username%}</div>
		<div class="statistics">{%single_user_activity%}</div>
		<div class="content personal-information {%single_user_suspended%}">{%single_user_email%}</div>

	</div>

	<div class="options-container">{%single_user_follow_unfollow%}</div>

	<div class="clear"></div>
</div>