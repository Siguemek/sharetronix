$(document).bind("mobileinit", function(){
  $.extend(  $.mobile , {
    defaultPageTransition: 'slide'
  });
});
