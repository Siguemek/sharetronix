<?php
	echo 'Error 404: no such page found!';