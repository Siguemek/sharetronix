<?php
	
	$folders = array();
	$folders[] = './themes/';
	$folders[] = './storage/attachments/';
	$folders[] = './storage/avatars/thumbs1/';
	$folders[] = './storage/avatars/thumbs2/';
	$folders[] = './storage/avatars/thumbs3/';
	$folders[] = './storage/avatars/thumbs4/';
	$folders[] = './storage/avatars/thumbs5/';
	$folders[] = './storage/avatars/';
	$folders[] = './storage/tmp/';
	$folders[] = './system/cache/';
	$folders[] = './system/cache_html/';
	$folders[] = './system/languages/';
	$folders[] = './system/tmp/';
	$folders[] = './apps/';
	$folders[] = './.htaccess';
	$folders[] = './system/';
	