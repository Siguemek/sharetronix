<?php

	$folders = array();
	$folders['3.0.0'] = array(
							'./storage/attachments/',
				 			'./storage/avatars/thumbs1/',
							'./storage/avatars/thumbs2/',
							'./storage/avatars/thumbs3/',
							'./storage/avatars/thumbs4/',
							'./storage/avatars/thumbs5/',
							'./storage/avatars/',
							'./storage/tmp/',
							'./system/cache_html/',
							'./system/languages/',
							'./apps/',
	);
	
	$folders['3.1.0'] = array(
							'./system/tmp/',
	);
	
