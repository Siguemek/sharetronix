	</div>
		<div class="clear"></div>
			</div>
			<div id="footer-spacer"></div>
		</div>

		<div class="footer-container">			
			<div id="footer">
				
					
				<div class="right">
					<span>
						
						<!-- "Powered by Sharetronix" backlink -->
							<!--
							You are required to keep the "Powered by Sharetronix" backlink
							as per the Sharetronix License: http://developer.sharetronix.com/license
							
							To remove the link, please visit this page: http://developer.sharetronix.com/linkremoval
							-->
							
							Powered by <a href="http://sharetronix.com" target="_blank">Sharetronix</a>
							
						<!-- "Powered by Sharetronix" backlink END -->
							
					</span> 
				</div>
			</div>
		</div>
	

	
	
	</body>
</html>






			